<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Secoes extends Model
{
    //
}
