<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstadoSistema extends Model
{
    //
}
