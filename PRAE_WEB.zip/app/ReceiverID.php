<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReceiverID extends Model
{
    //
}
