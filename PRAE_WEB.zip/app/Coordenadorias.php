<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Coordenadorias extends Model
{
    //
}
